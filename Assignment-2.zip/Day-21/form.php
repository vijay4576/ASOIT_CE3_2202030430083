<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <style>
        body{
            text-align: center;
            
        }
        form{
            background-color: gray;
            display: block;
            position: relative;
            padding: 10px;
            margin-left:500px ;
            margin-right:500px ;
            margin-top:50px ;
            border-radius:20px;
            opacity: 70%;
            
        }
    </style>
</head>

<body>
    <form action=form.php method="post">
    <h2>form</h2>
    <b>first name :</b>
    <input type="text" placeholder="Enter Fname" id="Fname" name="Fname"><br><br>
    <b>last name :</b>
    <input type="text" placeholder="Enter Lname" id="Lname" name="Lname"><br><br>
    <b>E-mail : </b>
    <input style="margin-left: 20px;" type="text" placeholder="Enter E-mail" id="Email" name="Email"><br><br>
    <b>phone no :</b>
    <input type="text" placeholder="Enter phone no" id="pno" name="pno"><br><br>
    <button type="submit">submit</button>
    </form>

    <?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "form";

    $conn=mysqli_connect($servername,$username,$password,$databasename);
    
    if($conn->connect_error){
        die("connection failed:".$conn->connect_error);
    }
    echo "connection successfully";

    $Fname=$_POST['Fname'];
    $Lname=$_POST['Lname'];
    $Email=$_POST['Email'];
    $pno=$_POST['pno'];

    $sql="INSERT INTO `employee` (`first_name`, `last_name`, `e-mail`, `Phone`) VALUES ('$Fname', '$Lname', '$Email', '$pno')";

    $conn->query($sql)==true;
    $conn->close();
    ?>
</body>
</html>
