<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "sou";

    $conn=mysqli_connect($servername,$username,$password,$databasename);
    
    if($conn->connect_error){
        die("connection failed:".$conn->connect_error);
    }
    echo "connection successfully";
    
    $sql="INSERT INTO `student`(`name`,`Enrollment no`,`E-mail`,`phone`) VALUES('amin','2202030430083','vijay@gmail.com','1254789525')";

    $conn->query($sql)==true;
?>