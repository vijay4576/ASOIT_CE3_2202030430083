<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <style>
        body
        {
            background-image:url('vpp.jpg');
            background-size:cover;
            display: block;
            position: relative;
            padding: 10px;
            margin-left:500px ;
            margin-right:500px ;
            margin-top:80px ;
            border-radius:20px;
        }
        .con{
            text-align:center;
        }
       input{
            border-radius: 10px;
            padding-right:50px;
            padding-bottom:5px;
        }
        form{
            background-color: rgba(129, 130, 146,0.5) ;
            border-radius:15%;
        }
        button{
            padding-left:25px;
            padding-right:25px;
            padding-top:5px;
            padding-bottom:5px;
            font-size:20px;
            background-color:gray;
        }
    </style>
</head>

<body>
    <script>
function myFunction() {
  alert("can you submit your feedback ?");
}
</script>
    <form action=form.php method="post"><br>
    <div class="con">
    <h2>Feedback form</h2>
    <b>first name :</b>
    <input type="text" placeholder="Enter Fname" id="Fname" name="Fname" required><br><br>
    <b>last name :</b>
    <input type="text" placeholder="Enter Lname" id="Lname" name="Lname" required><br><br>
    <b>E-mail : </b>
    <input style="margin-left: 20px;" type="email" placeholder="Enter E-mail" id="Email" name="Email" required><br><br>
    <b>phone no :</b>
    <input type="number" placeholder="Enter phone no" id="pno" name="pno" required><br><br>
</div>
    <b style="margin-left:20px;">Feedback :</b><br>
    <center><textarea type="text" placeholder="write subject..." id="FB" name="FB" style="padding-bottom:100px; padding-right:130px;" required></textarea></center><br>
    <center><button type="submit" onclick="myFunction()">submit</button></center><br>
    </form>

<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "form";

    $conn=mysqli_connect($servername,$username,$password,$databasename);
    
    if($conn->connect_error){
        die("connection failed:".$conn->connect_error);
    }
    echo "connection successfully";

    $Fname=$_POST['Fname'];
    $Lname=$_POST['Lname'];
    $Email=$_POST['Email'];
    $pno=$_POST['pno'];
    $FB=$_POST['FB'];

    $sql="INSERT INTO `employee` (`first name`, `last name`, `e-mail`, `Phone`,`feedback`) VALUES ('$Fname', '$Lname', '$Email', '$pno','$FB')";
    $conn->query($sql)==true;
    $conn->close();
?>
</body>
</html>
